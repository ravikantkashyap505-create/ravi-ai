Ravi AI Starter (Android-friendly web app)

Files:
- index.html: starter interface

How to try on Android:
1. Extract Ravi_AI_Starter.zip using your phone's Files app.
2. Open index.html in a browser if your phone allows local HTML files.
3. For a better installable app experience, host this folder on a static hosting service and use Chrome > menu > Add to Home screen.

Important limitations:
- This is a starter UI/demo, not a connected large language model.
- It does not perform live internet search or control phone apps.
- To add real AI safely, use a backend/proxy and keep provider API keys on the server, not in public HTML.
- Voice recognition support depends on browser and permissions.
